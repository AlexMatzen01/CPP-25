//! Copyright (c) Alexander Matzen. All rights reserved.
//! Author: Alexander Matzen
//! Licensed under the MIT license
//! Edit started 1/10/26

// Combat.cpp - Turn-based combat system
// Handles player vs. enemy battles, status effects, and combat resolution
//
// CLASS: CombatSystem
// PURPOSE: Manages all turn-based combat encounters between player and enemies
// 
// KEY ATTRIBUTES:
//   - playerRef: Reference to the player character
//   - gameDifficulty: Difficulty level (1-3) affecting enemy stats and AI
//   - combatLog: Vector storing all combat messages for replay/UI
//   - combatEnded: Flag to signal when combat concludes
//
// KEY METHODS:
//   - startCombat(enemies): Initiate combat with enemy group
//   - calculateAttack(): Determine hit/miss/damage of attack
//   - applyStatusEffect(): Apply buff/debuff to target
//   - healTarget(): Apply healing to character
//   - displayCombatStatus(): Render current combat state
//   - determineTurnOrder(): Calculate action sequence based on speed stats

#include "../include/Combat.h"
#include "../include/Utils.h"
#include "../include/Constants.h"
#include "../include/Inventory.h"
#include <iostream>
#include <algorithm>
#include <sstream>
#include <cmath>

namespace AQE {

namespace {
    // Helper function: Convert enemy intent enum to readable string
    // Intent display helps players predict enemy actions and make tactical decisions
    std::string intentToString(EnemyIntent intent) {
        switch (intent) {
            case EnemyIntent::ATTACK_LIGHT: return "Light Attack";
            case EnemyIntent::ATTACK_HEAVY: return "Heavy Attack";
            case EnemyIntent::DEFEND: return "Defend";
            case EnemyIntent::DEBUFF: return "Debuff";
            case EnemyIntent::BUFF: return "Buff";
            case EnemyIntent::HEAL: return "Heal";
            case EnemyIntent::CONTROL: return "Control";
            case EnemyIntent::SUMMON: return "Summon";
            case EnemyIntent::CHARGE: return "Charge";
            default: return "Unknown";
        }
    }

    // Calculate the highest vulnerability bonus from active status effects
    // Vulnerable effects increase damage taken; we use max to prevent stacking abuse
    int computeVulnerablePercent(const std::vector<StatusEffect>& effects) {
        int bonus = 0;
        for (const auto& e : effects) {
            // Only check effects that apply vulnerability debuff
            if (e.appliesVulnerable) {
                // Use max() to get the strongest vulnerability, not cumulative
                bonus = std::max(bonus, e.vulnerablePercent);
            }
        }
        return bonus;
    }

    // Check if target is stunned (stun prevents any action that turn)
    bool hasStun(const std::vector<StatusEffect>& effects) {
        for (const auto& e : effects) {
            // Stun effect must still be active (turnsRemaining > 0) to take effect
            if (e.appliesStun && e.turnsRemaining > 0) {
                return true;
            }
        }
        return false;
    }
}





// Constructor: Initialize combat system with player reference and difficulty level
CombatSystem::CombatSystem(Player& player, int difficulty)
    : playerRef(player), gameDifficulty(difficulty),
      combatEnded(false), playerVictory(false) {
    
    // Clamp difficulty to valid range (1-3)
    // Difficulty affects enemy stats and behavior throughout combat
    if (gameDifficulty < 1) gameDifficulty = 1;
    if (gameDifficulty > 3) gameDifficulty = 3;
}





CombatResult CombatSystem::startCombat(std::vector<Enemy>& enemies) {
    CombatResult result;
    combatLog.clear();
    combatEnded = false;
    playerVictory = false;
    std::vector<Enemy> defeatedEnemies;
    
    
    enemies.erase(
        std::remove_if(enemies.begin(), enemies.end(),
            [](const Enemy& e) { return e.stats.currentHP <= 0; }),
        enemies.end()
    );
    
    if (enemies.empty()) {
        result.playerWon = true;
        return result;
    }
    
    
    clearScreen();
    std::cout << "\n";
    displaySeparator(60, '=');
    printColor(centerString("!!! COMBAT INITIATED !!!", 60), Color::BRIGHT_RED);
    displaySeparator(60, '=');
    
    
    std::cout << "\nYou face:\n";
    for (size_t i = 0; i < enemies.size(); ++i) {
        std::cout << "  " << (i + 1) << ". " << colorize(enemies[i].name, Color::RED);
        if (enemies[i].isBoss) std::cout << colorize(" [BOSS]", Color::BRIGHT_MAGENTA);
        std::cout << "\n";
        if (!enemies[i].dialogue.empty()) {
            std::cout << "     \"" << colorize(enemies[i].dialogue, Color::YELLOW) << "\"\n";
        }
    }
    
    log("Combat started against " + std::to_string(enemies.size()) + " enemies.");
    pause("\nPress Enter to begin combat...");
    
    
    result.playerWon = combatLoop(enemies, defeatedEnemies);
    result.playerDied = !playerRef.isAlive;
    result.playerFled = combatEnded && !result.playerWon && playerRef.isAlive;
    
    
    if (result.playerWon) {
        result.experienceGained = calculateExperience(defeatedEnemies);
        result.goldGained = calculateGold(defeatedEnemies);
        result.loot = generateLoot(defeatedEnemies);
        
        
        playerRef.experience += result.experienceGained;
        playerRef.gold += result.goldGained;
        
        
        for (const Enemy& enemy : defeatedEnemies) {
            playerRef.totalKills++;
            if (enemy.isBoss) {
                playerRef.bossesDefeated++;
            }
        }
        
        
        for (const Item& item : result.loot) {
            playerRef.inventory.push_back(item);
        }
        
        
        std::cout << "\n";
        displaySeparator(60, '=');
        std::cout << VICTORY_ART;
        displaySeparator(60, '=');
        std::cout << "\nVictory! You have defeated your enemies!\n";
        std::cout << "Experience gained: " << result.experienceGained << "\n";
        std::cout << "Gold gained: " << result.goldGained << "\n";
        
        if (!result.loot.empty()) {
            std::cout << "Items found:\n";
            for (const Item& item : result.loot) {
                std::cout << "  - " << item.name << " [" 
                          << rarityToString(item.rarity) << "]"
                          << " (iLvl " << item.itemLevel;
                if (item.hasUniquePerk && !item.uniquePerkName.empty()) {
                    std::cout << ", Perk: " << item.uniquePerkName;
                }
                std::cout << ")\n";
            }
        }
    } else if (!playerRef.isAlive) {
        
        std::cout << "\n";
        std::cout << GAME_OVER_ART;
        std::cout << "\nYou have been defeated...\n";
        log("Player died in combat.");
    } else {
        
        std::cout << "\nYou escaped from combat!\n";
        log("Player fled from combat.");
    }
    
    result.combatLog = combatLog;
    return result;
}

CombatResult CombatSystem::startCombat(Enemy& enemy) {
    std::vector<Enemy> enemies = { enemy };
    CombatResult result = startCombat(enemies);
    enemy = enemies.empty() ? enemy : enemies[0];
    return result;
}

CombatStats CombatSystem::getEffectivePlayerStats() const {
    CombatStats effective = playerRef.stats;
    
    
    for (const Item& item : playerRef.inventory) {
        if (item.isEquipped) {
            effective.attack += item.attackBonus;
            effective.defense += item.defenseBonus;
            effective.critChance += item.critBonus;
            effective.dodgeChance += item.dodgeBonus;
            effective.speed += item.speedBonus;
        }
    }
    
    
    for (const StatusEffect& effect : playerRef.activeEffects) {
        effective.attack += effect.attackMod;
        effective.defense += effect.defenseMod;
        effective.critChance += effect.critMod;
        effective.dodgeChance += effect.dodgeMod;
        effective.speed += effect.speedMod;
    }
    
    
    if (effective.critChance > MAX_CRIT_CHANCE) effective.critChance = MAX_CRIT_CHANCE;
    if (effective.dodgeChance > MAX_DODGE_CHANCE) effective.dodgeChance = MAX_DODGE_CHANCE;
    if (effective.attack < 1) effective.attack = 1;
    if (effective.defense < 0) effective.defense = 0;
    
    return effective;
}

CombatStats CombatSystem::getEffectiveEnemyStats(const Enemy& enemy) const {
    CombatStats effective = enemy.stats;
    
    
    if (gameDifficulty == 1) {  
        effective.attack = static_cast<int>(effective.attack * EASY_DAMAGE_MULT);
        effective.defense = static_cast<int>(effective.defense * EASY_DEFENSE_MULT);
        effective.maxHP = static_cast<int>(effective.maxHP * EASY_HP_MULT);
    } else if (gameDifficulty == 3) {  
        effective.attack = static_cast<int>(effective.attack * HARD_DAMAGE_MULT);
        effective.defense = static_cast<int>(effective.defense * HARD_DEFENSE_MULT);
        effective.maxHP = static_cast<int>(effective.maxHP * HARD_HP_MULT);
    }
    
    return effective;
}





bool CombatSystem::combatLoop(std::vector<Enemy>& enemies, std::vector<Enemy>& defeatedEnemies) {
    while (!combatEnded) {
        
        processPlayerStatuses();
        for (Enemy& enemy : enemies) {
            processEnemyStatuses(enemy);
        }
        
        
        if (playerRef.stats.currentHP <= 0) {
            playerRef.isAlive = false;
            combatEnded = true;
            return false;
        }
        
        
        rollEnemyIntents(enemies);

        
        displayCombatStatus(enemies);
        
        
        auto turnOrder = determineTurnOrder(enemies);
        
        for (auto& [isPlayer, index] : turnOrder) {
            if (combatEnded) break;
            
            if (isPlayer) {
                
                
                int manaRegen = (playerRef.learnedSpells.size() > 0) ? 8 : 5;
                if (playerRef.stats.currentMana < playerRef.stats.maxMana) {
                    playerRef.stats.currentMana += manaRegen;
                    if (playerRef.stats.currentMana > playerRef.stats.maxMana) 
                        playerRef.stats.currentMana = playerRef.stats.maxMana;
                }
                
                
                for(auto& skill : playerRef.skills) {
                    if(skill.currentCooldown > 0) skill.currentCooldown--;
                }
                
                
                for(auto& spell : playerRef.learnedSpells) {
                    if(spell.currentCooldown > 0) spell.currentCooldown--;
                }

                std::cout << "\n--- YOUR TURN ---\n";
                int action = getPlayerAction();
                
                
                int caseCastSpell = -1;  
                int caseUseItem = -1;
                int caseFlee = -1;
                
                
                if (playerRef.learnedSpells.size() > 0) {
                    caseCastSpell = 3;
                    caseUseItem = 4;
                    caseFlee = 5;
                } else {
                    caseUseItem = 3;
                    caseFlee = 4;
                }
                
                switch (action) {
                    case 1: {  
                        int targetIdx = (enemies.size() == 1) ? 0 : selectTarget(enemies);
                        AttackResult result = playerAttack(enemies[targetIdx]);
                        displayMessage(result.message);
                        
                        if (enemies[targetIdx].stats.currentHP <= 0) {
                            displayMessage(enemies[targetIdx].name + " " + 
                                         randomElement(DEATH_TEXT));
                        }
                        break;
                    }
                    case 2: {  
                        if (playerRef.skills.empty()) {
                            std::cout << "You have no skills learned!\n";
                            
                        } else {
                            std::cout << "\nAvailable Skills:\n";
                            for (size_t i = 0; i < playerRef.skills.size(); ++i) {
                                const Skill& skill = playerRef.skills[i];
                                std::string color = (playerRef.stats.currentMana >= skill.manaCost && skill.currentCooldown <= 0) 
                                                    ? Color::BRIGHT_WHITE : Color::RED;
                                std::cout << "  " << (i + 1) << ". " << colorize(skill.name, color)
                                          << " (MP: " << skill.manaCost << ")";
                                if (skill.currentCooldown > 0) std::cout << " [CD: " << skill.currentCooldown << "]";
                                std::cout << "\n";
                            }
                            std::cout << "  0. Cancel\n";
                            
                            int skillChoice = getValidatedInt("Choose skill: ", 0, static_cast<int>(playerRef.skills.size()));
                            
                            if (skillChoice > 0) {
                                int targetIdx = 0;
                                if (!playerRef.skills[skillChoice-1].isHeal) {
                                    targetIdx = (enemies.size() == 1) ? 0 : selectTarget(enemies);
                                }
                                AbilityResult result = usePlayerAbility(skillChoice - 1, &enemies[targetIdx]);
                                displayMessage(result.message);
                            }
                        }
                        break;
                    }
                    case 3: {  
                        if (caseCastSpell == 3) {
                            if (playerRef.learnedSpells.empty()) {
                                std::cout << "You have no spells learned!\n";
                            } else {
                                std::cout << "\nAvailable Spells:\n";
                                for (size_t i = 0; i < playerRef.learnedSpells.size(); ++i) {
                                    const struct Spell& spell = playerRef.learnedSpells[i];
                                    std::string color = (playerRef.stats.currentMana >= spell.manaCost && spell.currentCooldown <= 0) 
                                                        ? Color::BRIGHT_CYAN : Color::RED;
                                    std::cout << "  " << (i + 1) << ". " << colorize(spell.name, color)
                                              << " (MP: " << spell.manaCost << ")";
                                    if (spell.currentCooldown > 0) std::cout << " [CD: " << spell.currentCooldown << "]";
                                    std::cout << "\n";
                                }
                                std::cout << "  0. Cancel\n";
                                
                                int spellChoice = getValidatedInt("Choose spell: ", 0, static_cast<int>(playerRef.learnedSpells.size()));
                                
                                if (spellChoice > 0) {
                                    int targetIdx = 0;
                                    if (!playerRef.learnedSpells[spellChoice-1].isHeal && !playerRef.learnedSpells[spellChoice-1].isAOE) {
                                        targetIdx = (enemies.size() == 1) ? 0 : selectTarget(enemies);
                                    }
                                    SpellResult result = castSpellInCombat(spellChoice - 1, &enemies[targetIdx], &enemies);
                                    displayMessage(result.message);
                                }
                            }
                            break;
                        }
                        
                        [[fallthrough]];
                    }
                    case 4: {  
                        if (caseUseItem == action) {
                            auto combatItems = getCombatItemIndices(playerRef);
                            if (combatItems.empty()) {
                                std::cout << "No usable items!\n";
                            } else {
                                std::cout << "\nUsable items:\n";
                                for (size_t i = 0; i < combatItems.size(); ++i) {
                                    const Item& item = playerRef.inventory[combatItems[i]];
                                    std::cout << "  " << (i + 1) << ". " << item.name;
                                    if (item.healAmount > 0) {
                                        std::cout << " (Heals " << item.healAmount << " HP)";
                                    }
                                    std::cout << "\n";
                                }
                                std::cout << "  0. Cancel\n";
                                
                                int choice = getValidatedInt("Choose item: ", 0, 
                                    static_cast<int>(combatItems.size()));
                                if (choice > 0) {
                                    useItemInCombat(combatItems[choice - 1]);
                                }
                            }
                            break;
                        }
                        
                        [[fallthrough]];
                    }
                    case 5: {  
                        if (caseFlee == action) {
                            if (attemptFlee(enemies)) {
                                combatEnded = true;
                                return false;
                            }
                            break;
                        }
                    }
                }
            } else {
                
                if (index < 0 || index >= static_cast<int>(enemies.size())) continue;
                Enemy& enemy = enemies[index];
                
                if (enemy.stats.currentHP <= 0) continue;  

                if (hasStun(enemy.activeEffects)) {
                    displayMessage(enemy.name + " is stunned and loses the turn!");
                    continue;
                }
                
                std::cout << "\n--- " << toUpper(enemy.name) << "'S TURN ---\n";
                delay(300);
                
                
                bool acted = false;
                if (enemy.nextIntent == EnemyIntent::HEAL || shouldEnemyUseAbility(enemy)) {
                    AbilityResult result = useEnemyAbility(enemy);
                    displayMessage(result.message);
                    acted = result.used;
                }
                if (!acted) {
                    if (enemy.nextIntent == EnemyIntent::DEFEND) {
                        StatusEffect guard;
                        guard.name = "Guard";
                        guard.turnsRemaining = 2;
                        guard.shieldAmount = enemy.stats.defense / 2 + 5;
                        guard.isDebuff = false;
                        enemy.activeEffects.push_back(guard);
                        displayMessage(enemy.name + " braces for impact, raising a guard!");
                    } else {
                        
                        AttackResult result = enemyAttack(enemy);
                        displayMessage(result.message);
                        
                        
                        if (playerRef.stats.currentHP <= 0) {
                            playerRef.isAlive = false;
                            combatEnded = true;
                            return false;
                        }
                    }
                }
            }
        }
        
        
        for (const Enemy& enemy : enemies) {
            if (enemy.stats.currentHP <= 0) {
                defeatedEnemies.push_back(enemy);
            }
        }

        
        enemies.erase(
            std::remove_if(enemies.begin(), enemies.end(),
                [](const Enemy& e) { return e.stats.currentHP <= 0; }),
            enemies.end()
        );
        
        
        if (enemies.empty()) {
            combatEnded = true;
            return true;
        }
        
        playerRef.combatTurns++;
        playerRef.totalTurns = playerRef.explorationTurns + playerRef.combatTurns;
    }
    
    return playerVictory;
}

void CombatSystem::displayCombatStatus(const std::vector<Enemy>& enemies) const {
    clearScreen();
    std::cout << "\n";
    displaySeparator(60, '-');
    printColor(centerString("COMBAT STATUS", 60), Color::BRIGHT_WHITE);
    displaySeparator(60, '-');
    
    
    std::cout << "\n" << colorize(playerRef.name, Color::BRIGHT_GREEN) 
              << " (" << classToString(playerRef.charClass) << ")\n";
    
    
    std::cout << "HP: ";
    displayProgressBar(playerRef.stats.currentHP, playerRef.stats.maxHP, 25, "");
    std::cout << " " << playerRef.stats.currentHP << "/" << playerRef.stats.maxHP << "\n";
    
    
    std::cout << "MP: ";
    displayProgressBar(playerRef.stats.currentMana, playerRef.stats.maxMana, 25, "");
    std::cout << " " << playerRef.stats.currentMana << "/" << playerRef.stats.maxMana << "\n";
    
    CombatStats pStats = getEffectivePlayerStats();
    std::cout << "ATK: " << pStats.attack << " | DEF: " << pStats.defense
              << " | CRIT: " << pStats.critChance << "% | SPD: " << pStats.speed << "\n";
    
    
    if (!playerRef.activeEffects.empty()) {
        std::cout << "Effects: ";
        for (const StatusEffect& e : playerRef.activeEffects) {
            std::string color = e.isDebuff ? Color::RED : Color::CYAN;
            std::cout << colorize(e.name, color) << "(" << e.turnsRemaining << ") ";
        }
        std::cout << "\n";
    }
    
    
    std::cout << "\n--- " << colorize("ENEMIES", Color::RED) << " ---\n";
    for (size_t i = 0; i < enemies.size(); ++i) {
        const Enemy& enemy = enemies[i];
        std::cout << "\n" << (i + 1) << ". " << colorize(enemy.name, Color::RED);
        if (enemy.isBoss) std::cout << colorize(" [BOSS]", Color::BRIGHT_MAGENTA);
        std::cout << "\n";
        displayProgressBar(enemy.stats.currentHP, enemy.stats.maxHP, 25, "HP");

        std::cout << "Intent: " << intentToString(enemy.nextIntent) << "\n";
        if (!enemy.activeEffects.empty()) {
            std::cout << "Effects: ";
            for (const StatusEffect& e : enemy.activeEffects) {
                std::string color = e.isDebuff ? Color::RED : Color::CYAN;
                std::cout << colorize(e.name, color) << "(" << e.turnsRemaining << ") ";
            }
            std::cout << "\n";
        }
    }
    
    displaySeparator(60, '-');
}

int CombatSystem::getPlayerAction() const {
    std::vector<std::string> options;
    options.push_back("Attack");
    options.push_back("Skills");
    
    
    if (playerRef.learnedSpells.size() > 0) {
        options.push_back("Cast Spell");
    }
    
    options.push_back("Use Item");
    options.push_back("Attempt to Flee");
    
    return displayMenu("Choose your action", options);
}

int CombatSystem::selectTarget(const std::vector<Enemy>& enemies) const {
    std::cout << "\nSelect target:\n";
    for (size_t i = 0; i < enemies.size(); ++i) {
        std::cout << "  " << (i + 1) << ". " << enemies[i].name 
                  << " (HP: " << enemies[i].stats.currentHP << "/"
                  << enemies[i].stats.maxHP << ")\n";
    }
    
    return getValidatedInt("Target: ", 1, static_cast<int>(enemies.size())) - 1;
}

std::vector<std::pair<bool, int>> CombatSystem::determineTurnOrder(
    const std::vector<Enemy>& enemies) const {
    
    std::vector<std::pair<int, std::pair<bool, int>>> speedList;
    
    
    CombatStats pStats = getEffectivePlayerStats();
    speedList.push_back({pStats.speed + randomInt(0, 5), {true, 0}});
    
    
    for (size_t i = 0; i < enemies.size(); ++i) {
        if (enemies[i].stats.currentHP > 0) {
            CombatStats eStats = getEffectiveEnemyStats(enemies[i]);
            speedList.push_back({eStats.speed + randomInt(0, 5), {false, static_cast<int>(i)}});
        }
    }
    
    
    std::sort(speedList.begin(), speedList.end(),
              [](const auto& a, const auto& b) { return a.first > b.first; });
    
    
    std::vector<std::pair<bool, int>> result;
    for (const auto& entry : speedList) {
        result.push_back(entry.second);
    }
    
    return result;
}

void CombatSystem::rollEnemyIntents(std::vector<Enemy>& enemies) {
    for (Enemy& enemy : enemies) {
        if (enemy.stats.currentHP <= 0) {
            enemy.nextIntent = EnemyIntent::UNKNOWN;
            continue;
        }

        
        if (enemy.trueDamage > 0) {
            int roll = randomInt(1, 100);
            if (roll <= 30) {
                enemy.nextIntent = EnemyIntent::CHARGE;
            } else if (roll <= 55) {
                enemy.nextIntent = EnemyIntent::CONTROL;
            } else if (roll <= 80) {
                enemy.nextIntent = EnemyIntent::ATTACK_HEAVY;
            } else {
                enemy.nextIntent = EnemyIntent::ATTACK_LIGHT;
            }
            enemy.intentStrength = enemy.stats.attack + enemy.trueDamage;
            continue;
        }

        
        if (enemy.stats.currentHP < enemy.stats.maxHP / 3) {
            bool hasHeal = std::any_of(enemy.abilities.begin(), enemy.abilities.end(),
                [](const EnemyAbility& a) { return a.heals; });
            if (hasHeal) {
                if (randomChance(15)) {
                    enemy.nextIntent = EnemyIntent::HEAL;
                    enemy.intentStrength = 1;
                    continue;
                }
            }
        }

        
        EnemyAbility const* readyAbility = nullptr;
        for (const auto& ability : enemy.abilities) {
            if (ability.currentCooldown <= 0) {
                readyAbility = &ability;
                break;
            }
        }

        if (readyAbility) {
            if (readyAbility->heals) {
                
                if (randomChance(15)) {
                    enemy.nextIntent = EnemyIntent::HEAL;
                    enemy.intentStrength = readyAbility->damage;
                    continue;
                } else {
                    
                    if (readyAbility->damage > enemy.stats.attack * 1.2f) {
                        enemy.nextIntent = EnemyIntent::ATTACK_HEAVY;
                    } else {
                        enemy.nextIntent = EnemyIntent::DEBUFF;
                    }
                }
            } else if (readyAbility->damage > enemy.stats.attack * 1.2f) {
                enemy.nextIntent = EnemyIntent::ATTACK_HEAVY;
            } else {
                enemy.nextIntent = EnemyIntent::DEBUFF;
            }
            enemy.intentStrength = readyAbility->damage;
            continue;
        }

        
        if (enemy.stats.currentHP < enemy.stats.maxHP / 2 && randomChance(30)) {
            enemy.nextIntent = EnemyIntent::DEFEND;
            enemy.intentStrength = 0;
        } else {
            enemy.nextIntent = randomChance(30) ? EnemyIntent::ATTACK_HEAVY : EnemyIntent::ATTACK_LIGHT;
            enemy.intentStrength = enemy.stats.attack;
        }
    }
}





AttackResult CombatSystem::playerAttack(Enemy& target) {
    AttackResult result;
    CombatStats pStats = getEffectivePlayerStats();
    CombatStats eStats = getEffectiveEnemyStats(target);
    
    
    if (!rollToHit(pStats.speed, eStats.dodgeChance)) {
        result.hit = false;
        result.dodged = true;
        result.message = target.name + " dodges your attack!";
        log(result.message);
        return result;
    }
    
    result.hit = true;
    
    
    result.critical = rollCritical(pStats.critChance);
    
    
    int baseDamage = pStats.attack + randomInt(-1, 3) + 1;
    result.rawDamage = baseDamage;
    result.damageDealt = calculateFinalDamage(baseDamage, eStats.defense, result.critical);

    
    int vuln = computeVulnerablePercent(target.activeEffects);
    if (vuln > 0) {
        result.damageDealt += (result.damageDealt * vuln) / 100;
    }

    result.damageDealt = applyShieldThenDamage(result.damageDealt, target.activeEffects, target.stats.currentHP);
    
    
    result.message = generateCombatMessage(playerRef.name, target.name, 
                                           result.damageDealt, result.critical, false);
    log(result.message);
    
    return result;
}

AttackResult CombatSystem::enemyAttack(const Enemy& attacker) {
    AttackResult result;
    CombatStats pStats = getEffectivePlayerStats();
    CombatStats eStats = getEffectiveEnemyStats(attacker);
    
    
    if (!rollToHit(eStats.speed, pStats.dodgeChance)) {
        result.hit = false;
        result.dodged = true;
        result.message = "You dodge " + attacker.name + "'s attack!";
        log(result.message);
        return result;
    }
    
    result.hit = true;
    
    
    result.critical = rollCritical(eStats.critChance);
    
    
    int baseDamage = eStats.attack + randomInt(-1, 2);
    if (attacker.nextIntent == EnemyIntent::CHARGE) {
        baseDamage += std::max(1, eStats.attack / 4);
    }
    result.rawDamage = baseDamage;
    result.damageDealt = calculateFinalDamage(baseDamage, pStats.defense, result.critical);
    
    
    
    int vuln = computeVulnerablePercent(playerRef.activeEffects);
    if (vuln > 0) {
        result.damageDealt += (result.damageDealt * vuln) / 100;
    }

    result.damageDealt = applyShieldThenDamage(result.damageDealt, playerRef.activeEffects, playerRef.stats.currentHP);

    
    if (attacker.trueDamage > 0) {
        int unavoidable = attacker.trueDamage + randomInt(0, std::max(1, attacker.trueDamage / 2));
        if (attacker.nextIntent == EnemyIntent::CHARGE) {
            unavoidable += std::max(1, attacker.trueDamage / 2);
        }

        playerRef.stats.currentHP -= unavoidable;
        if (playerRef.stats.currentHP < 0) playerRef.stats.currentHP = 0;
        result.damageDealt += unavoidable;
    }
    
    
    result.message = generateCombatMessage(attacker.name, playerRef.name,
                                           result.damageDealt, result.critical, false);
    if (attacker.trueDamage > 0) {
        result.message += "\n" + attacker.name + " rends reality for unavoidable damage!";
    }
    log(result.message);
    
    return result;
}

bool CombatSystem::rollToHit(int attackerSpeed, int targetDodge) const {
    
    int hitChance = 90 + attackerSpeed - targetDodge;
    if (hitChance < 30) hitChance = 30;   
    if (hitChance > 98) hitChance = 98;   
    return randomChance(hitChance);
}

bool CombatSystem::rollCritical(int critChance) const {
    return randomChance(critChance);
}

int CombatSystem::calculateFinalDamage(int baseDamage, int defense, bool isCrit) const {
    float damage = static_cast<float>(baseDamage);

    if (isCrit) {
        damage *= BASE_CRIT_MULTIPLIER;
    }

    
    
    const float k = 72.0f;
    float mitigation = static_cast<float>(defense) / (static_cast<float>(defense) + k);
    if (mitigation < 0.0f) mitigation = 0.0f;
    if (mitigation > 0.65f) mitigation = 0.65f; 

    int finalDamage = static_cast<int>(std::floor(damage * (1.0f - mitigation)));
    if (finalDamage < 1) finalDamage = 1;
    return finalDamage;
}





AbilityResult CombatSystem::usePlayerAbility(int abilityIndex, Enemy* target) {
    AbilityResult result;
    
    if (abilityIndex < 0 || abilityIndex >= static_cast<int>(playerRef.skills.size())) {
        result.used = false;
        result.message = "Invalid skill!";
        return result;
    }
    
    Skill& skill = playerRef.skills[abilityIndex];
    
    
    if (skill.currentCooldown > 0) {
        result.used = false;
        result.message = skill.name + " is on cooldown! (" + std::to_string(skill.currentCooldown) + " turns)";
        return result;
    }
    
    
    if (playerRef.stats.currentMana < skill.manaCost) {
        result.used = false;
        result.message = "Not enough Mana! Need " + std::to_string(skill.manaCost);
        return result;
    }
    
    
    playerRef.stats.currentMana -= skill.manaCost;
    skill.currentCooldown = skill.cooldown;
    
    result.used = true;
    result.success = true;
    
    if (skill.isHeal) {
        
        int healAmount = static_cast<int>(playerRef.stats.magicPower * skill.damageMultiplier);
        int oldHP = playerRef.stats.currentHP;
        playerRef.stats.currentHP += healAmount;
        if (playerRef.stats.currentHP > playerRef.stats.maxHP) {
            playerRef.stats.currentHP = playerRef.stats.maxHP;
        }
        result.healingDone = playerRef.stats.currentHP - oldHP;
        result.message = "You cast " + colorize(skill.name, Color::CYAN) + 
                         " and heal for " + colorize(std::to_string(result.healingDone), Color::GREEN) + " HP!";
    } else {
        
        if (target == nullptr) {
            result.used = false;
            result.message = "No target selected!";
            return result; 
        }
        
        CombatStats pStats = getEffectivePlayerStats();
        CombatStats eStats = getEffectiveEnemyStats(*target);
        
        int baseDamage = skill.isMagical ? pStats.magicPower : pStats.attack;
        int defense = skill.isMagical ? eStats.magicResist : eStats.defense;
        
        int damage = static_cast<int>(baseDamage * skill.damageMultiplier) - defense;
        if (damage < 1) damage = 1;
        
        
        if (randomChance(pStats.critChance)) {
            damage *= BASE_CRIT_MULTIPLIER;
            result.message = "CRITICAL HIT! ";
        }
        
        target->stats.currentHP -= damage;
        if (target->stats.currentHP < 0) target->stats.currentHP = 0;
        
        result.damageDealt = damage;
        result.message += "You use " + colorize(skill.name, Color::CYAN) + " on " + 
                          colorize(target->name, Color::RED) + " for " + 
                          colorize(std::to_string(damage), Color::BRIGHT_RED) + " damage!";
                          
        
        if (skill.effect.turnsRemaining > 0) {
            target->activeEffects.push_back(skill.effect);
            result.message += "\n" + target->name + " is affected by " + skill.effect.name + "!";
        }
    }
    
    log(result.message);
    return result;
}

SpellResult CombatSystem::castSpellInCombat(int spellIndex, Enemy* target, std::vector<Enemy>* enemies) {
    SpellResult result;
    
    if (spellIndex < 0 || spellIndex >= static_cast<int>(playerRef.learnedSpells.size())) {
        result.cast = false;
        result.message = "Invalid spell!";
        return result;
    }
    
    Spell& spell = playerRef.learnedSpells[spellIndex];
    
    
    if (spell.currentCooldown > 0) {
        result.cast = false;
        result.message = spell.name + " is on cooldown! (" + std::to_string(spell.currentCooldown) + " turns)";
        return result;
    }
    
    
    if (playerRef.stats.currentMana < spell.manaCost) {
        result.cast = false;
        result.message = "Not enough Mana! Need " + std::to_string(spell.manaCost);
        return result;
    }
    
    
    playerRef.stats.currentMana -= spell.manaCost;
    spell.currentCooldown = spell.cooldown;
    
    result.cast = true;
    
    
    if (spell.isHeal) {
        int healAmount = static_cast<int>(playerRef.stats.magicPower * spell.healMultiplier);
        int oldHP = playerRef.stats.currentHP;
        playerRef.stats.currentHP += healAmount;
        if (playerRef.stats.currentHP > playerRef.stats.maxHP) {
            playerRef.stats.currentHP = playerRef.stats.maxHP;
        }
        result.healingDone = playerRef.stats.currentHP - oldHP;
        result.message = "You cast " + colorize(spell.name, Color::BRIGHT_CYAN) + 
                         " and heal for " + colorize(std::to_string(result.healingDone), Color::GREEN) + " HP!";
        log(result.message);
        return result;
    }
    
    
    if (target == nullptr && !spell.isAOE) {
        result.cast = false;
        result.message = "No target selected!";
        return result;
    }
    
    
    if (!spell.isAOE) {
        CombatStats pStats = getEffectivePlayerStats();
        CombatStats eStats = getEffectiveEnemyStats(*target);
        
        int baseDamage = static_cast<int>(pStats.magicPower * spell.damageMultiplier);
        int defense = eStats.magicResist;
        
        int damage = baseDamage - defense;
        if (damage < 1) damage = 1;
        
        
        if (randomChance(pStats.critChance)) {
            damage *= BASE_CRIT_MULTIPLIER;
            result.message = "CRITICAL SPELL! ";
        }
        
        target->stats.currentHP -= damage;
        if (target->stats.currentHP < 0) target->stats.currentHP = 0;
        
        result.damageDealt = damage;
        result.affectedTargets.push_back(0);
        result.message += "You cast " + colorize(spell.name, Color::BRIGHT_CYAN) + " on " + 
                          colorize(target->name, Color::RED) + " for " + 
                          colorize(std::to_string(damage), Color::BRIGHT_RED) + " damage!";
        
        
        if (spell.dotDamage > 0) {
            StatusEffect dotEffect;
            dotEffect.name = spell.name + " Dot";
            dotEffect.dotDamage = spell.dotDamage;
            dotEffect.dotIsMagic = true;
            dotEffect.turnsRemaining = spell.dotTurns;
            dotEffect.isDebuff = true;
            target->activeEffects.push_back(dotEffect);
            result.message += "\n" + target->name + " is burning!";
        }
        
        
        if (spell.appliedEffect.turnsRemaining > 0) {
            target->activeEffects.push_back(spell.appliedEffect);
            result.message += "\n" + target->name + " is " + spell.appliedEffect.name + "!";
        }
    } else {
        
        if (enemies == nullptr) {
            result.cast = false;
            result.message = "No enemies available for AOE spell!";
            return result;
        }

        CombatStats pStats = getEffectivePlayerStats();
        int baseDamage = static_cast<int>(pStats.magicPower * spell.damageMultiplier);
        
        result.message = "You cast " + colorize(spell.name, Color::BRIGHT_CYAN) + " on all enemies!\n";
        
        for (size_t i = 0; i < enemies->size(); ++i) {
            Enemy& enemy = (*enemies)[i];
            if (enemy.stats.currentHP <= 0) continue;
            
            CombatStats eStats = getEffectiveEnemyStats(enemy);
            int defense = eStats.magicResist;
            
            int damage = baseDamage - defense;
            if (damage < 1) damage = 1;
            
            if (randomChance(pStats.critChance)) {
                damage *= BASE_CRIT_MULTIPLIER;
            }
            
            enemy.stats.currentHP -= damage;
            if (enemy.stats.currentHP < 0) enemy.stats.currentHP = 0;
            
            result.damageDealt += damage;
            result.affectedTargets.push_back(i);
            result.message += "  " + enemy.name + " takes " + std::to_string(damage) + " damage!\n";
            
            
            if (spell.appliedEffect.turnsRemaining > 0) {
                enemy.activeEffects.push_back(spell.appliedEffect);
            }
        }
    }
    
    log(result.message);
    return result;
}

AbilityResult CombatSystem::useEnemyAbility(Enemy& enemy) {
    AbilityResult result;
    
    if (enemy.abilities.empty()) {
        
        AttackResult attack = enemyAttack(enemy);
        result.message = attack.message;
        return result;
    }
    
    
    for (EnemyAbility& ability : enemy.abilities) {
        if (ability.currentCooldown <= 0) {
            result.used = true;
            result.success = true;
            
            if (ability.heals) {
                
                int healed = ability.healAmount;
                enemy.stats.currentHP += healed;
                if (enemy.stats.currentHP > enemy.stats.maxHP) {
                    enemy.stats.currentHP = enemy.stats.maxHP;
                }
                result.healingDone = healed;
                result.message = enemy.name + " uses " + ability.name + 
                                " and heals for " + std::to_string(healed) + " HP!";
            } else {
                
                CombatStats pStats = getEffectivePlayerStats();
                int damage = calculateFinalDamage(ability.damage, pStats.defense, false);
                int vuln = computeVulnerablePercent(playerRef.activeEffects);
                if (vuln > 0) {
                    damage += (damage * vuln) / 100;
                }

                damage = applyShieldThenDamage(damage, playerRef.activeEffects, playerRef.stats.currentHP);
                if (playerRef.stats.currentHP < 0) playerRef.stats.currentHP = 0;

                result.damageDealt = damage;
                result.message = enemy.name + " uses " + ability.name + 
                                "! You take " + std::to_string(damage) + " damage!";
            }
            
            ability.currentCooldown = ability.cooldown;
            log(result.message);
            return result;
        }
    }
    
    
    AttackResult attack = enemyAttack(enemy);
    result.message = attack.message;
    return result;
}

bool CombatSystem::shouldEnemyUseAbility(const Enemy& enemy) const {
    if (enemy.abilities.empty()) return false;
    
    for (const EnemyAbility& ability : enemy.abilities) {
        if (ability.currentCooldown <= 0 && randomFloat() < ability.triggerChance) {
            return true;
        }
    }
    return false;
}





void CombatSystem::applyStatusToPlayer(const StatusEffect& effect) {
    playerRef.activeEffects.push_back(effect);
    log("Status applied: " + effect.name);
}

void CombatSystem::processPlayerStatuses() {
    tickStatuses(playerRef.activeEffects, playerRef.stats, true);
    cleanupStatuses(playerRef.activeEffects);
}

void CombatSystem::processEnemyStatuses(Enemy& enemy) {
    
    for (EnemyAbility& ability : enemy.abilities) {
        if (ability.currentCooldown > 0) {
            ability.currentCooldown--;
        }
    }

    tickStatuses(enemy.activeEffects, enemy.stats, false);
    cleanupStatuses(enemy.activeEffects);
}

void CombatSystem::tickStatuses(std::vector<StatusEffect>& effects, CombatStats& stats, bool isPlayer) {
    for (StatusEffect& effect : effects) {
        if (effect.turnsRemaining > 0) {
            
            if (effect.dotDamage > 0) {
                int dmg = effect.dotDamage;
                stats.currentHP -= dmg;
                if (stats.currentHP < 0) stats.currentHP = 0;
                log((isPlayer ? "Player" : "Enemy") + std::string(" suffers ") + std::to_string(dmg) + " from " + effect.name);
            }

            effect.turnsRemaining--;
        }
    }
}

void CombatSystem::cleanupStatuses(std::vector<StatusEffect>& effects) {
    effects.erase(
        std::remove_if(effects.begin(), effects.end(), [](const StatusEffect& e) {
            return e.turnsRemaining <= 0 && e.shieldAmount <= 0;
        }),
        effects.end());
}

int CombatSystem::applyShieldThenDamage(int incoming, std::vector<StatusEffect>& effects, int& hpPool) const {
    int remaining = incoming;
    int absorbed = 0;

    for (StatusEffect& e : effects) {
        if (e.shieldAmount <= 0 || remaining <= 0) continue;
        int used = std::min(e.shieldAmount, remaining);
        e.shieldAmount -= used;
        remaining -= used;
        absorbed += used;
    }

    if (remaining > 0) {
        int before = hpPool;
        hpPool -= remaining;
        if (hpPool < 0) hpPool = 0;
        absorbed += (before - hpPool);
    }

    return absorbed;
}





bool CombatSystem::attemptFlee(const std::vector<Enemy>& enemies) {
    
    CombatStats pStats = getEffectivePlayerStats();
    
    if (enemies.empty()) {
        return 50;  
    }
    
    int totalEnemySpeed = 0;
    for (const Enemy& enemy : enemies) {
        totalEnemySpeed += getEffectiveEnemyStats(enemy).speed;
    }
    int avgEnemySpeed = totalEnemySpeed / static_cast<int>(enemies.size());
    
    int speedDiff = pStats.speed - avgEnemySpeed;
    int fleeChance = FLEE_BASE_CHANCE + (speedDiff * SPEED_FLEE_BONUS);
    
    if (fleeChance < 10) fleeChance = 10;
    if (fleeChance > 80) fleeChance = 80;
    
    
    for (const Enemy& enemy : enemies) {
        if (enemy.isBoss) {
            fleeChance /= 2;
            break;
        }
    }
    
    if (randomChance(fleeChance)) {
        log("Player fled successfully.");
        return true;
    } else {
        displayMessage("You failed to escape!");
        log("Player failed to flee.");
        return false;
    }
}

bool CombatSystem::useItemInCombat(int itemIndex) {
    if (itemIndex < 0 || itemIndex >= static_cast<int>(playerRef.inventory.size())) {
        return false;
    }
    
    Item& item = playerRef.inventory[itemIndex];
    
    if (!item.isUsable || item.type != ItemType::CONSUMABLE) {
        std::cout << "You can't use that in combat!\n";
        return false;
    }
    
    
    if (item.healAmount > 0) {
        int healed = item.healAmount;
        playerRef.stats.currentHP += healed;
        if (playerRef.stats.currentHP > playerRef.stats.maxHP) {
            playerRef.stats.currentHP = playerRef.stats.maxHP;
        }
        std::cout << "You use " << item.name << " and restore " << healed << " HP!\n";
        log("Used " + item.name + ", healed " + std::to_string(healed) + " HP.");
    }
    
    
    if (item.duration > 0) {
        StatusEffect buff;
        buff.name = item.name + " Effect";
        buff.attackMod = item.attackBonus;
        buff.defenseMod = item.defenseBonus;
        buff.critMod = item.critBonus;
        buff.dodgeMod = item.dodgeBonus;
        buff.speedMod = item.speedBonus;
        buff.turnsRemaining = item.duration;
        buff.isDebuff = false;
        applyStatusToPlayer(buff);
        
        std::cout << "You gain a temporary buff!\n";
    }
    
    
    item.quantity--;
    if (item.quantity <= 0) {
        playerRef.inventory.erase(playerRef.inventory.begin() + itemIndex);
    }
    
    return true;
}





std::vector<Item> CombatSystem::generateLoot(const std::vector<Enemy>& enemies) {
    std::vector<Item> loot;
    
    for (const Enemy& enemy : enemies) {
        std::vector<Item> enemyLoot = rollLootTable(enemy);
        loot.insert(loot.end(), enemyLoot.begin(), enemyLoot.end());
    }
    
    return loot;
}

std::vector<Item> CombatSystem::rollLootTable(const Enemy& enemy) {
    std::vector<Item> drops;
    
        
        
        int materialDropChance = enemy.isBoss ? 80 : 50;
        int materialCount = enemy.isBoss ? randomInt(2, 4) : randomInt(1, 2);
    
        for (int i = 0; i < materialCount; ++i) {
            if (randomChance(materialDropChance)) {
                
                std::string materialType;
                if (enemy.name.find("Skeleton") != std::string::npos || 
                    enemy.name.find("Undead") != std::string::npos ||
                    enemy.name.find("Bone") != std::string::npos) {
                    materialType = randomChance(60) ? "Bone" : "Essence";
                } else if (enemy.name.find("Dragon") != std::string::npos ||
                           enemy.name.find("Dragon") != std::string::npos) {
                    materialType = "Dragon Scale";
                } else if (enemy.name.find("Spider") != std::string::npos ||
                           enemy.name.find("Arachnid") != std::string::npos) {
                    materialType = randomChance(70) ? "Leather" : "Cloth";
                } else if (enemy.name.find("Slime") != std::string::npos ||
                           enemy.name.find("Ooze") != std::string::npos) {
                    materialType = randomChance(50) ? "Essence" : "Herb";
                } else if (enemy.name.find("Vampire") != std::string::npos ||
                           enemy.name.find("Wraith") != std::string::npos) {
                    materialType = randomChance(60) ? "Essence" : "Crystal";
                } else if (enemy.name.find("Troll") != std::string::npos ||
                           enemy.name.find("Orc") != std::string::npos) {
                    materialType = randomChance(60) ? "Leather" : "Metal";
                } else if (enemy.name.find("Goblin") != std::string::npos ||
                           enemy.name.find("Mimic") != std::string::npos) {
                    materialType = randomChance(50) ? "Metal" : "Gem";
                } else if (enemy.name.find("Lich") != std::string::npos ||
                           enemy.name.find("Eye Tyrant") != std::string::npos ||
                           enemy.name.find("Beholder") != std::string::npos) {
                    materialType = randomChance(70) ? "Crystal" : "Essence";
                } else {
                    
                    materialType = (randomInt(1, 6) == 1) ? "Metal" : 
                                   (randomInt(1, 5) == 1) ? "Leather" :
                                   (randomInt(1, 4) == 1) ? "Wood" : "Cloth";
                }
            
                
                ItemRarity rarity = ItemRarity::COMMON;
                int rarityRoll = randomInt(1, 100);
                if (enemy.isBoss) {
                    if (rarityRoll > 80) rarity = ItemRarity::LEGENDARY;
                    else if (rarityRoll > 60) rarity = ItemRarity::EPIC;
                    else rarity = ItemRarity::COMMON;
                }

                
                Item material;
                material.id = 5000 + randomInt(0, 999);
                material.name = (rarity == ItemRarity::LEGENDARY) ? "Refined " + materialType + " Material" :
                                (rarity == ItemRarity::EPIC) ? "Pure " + materialType + " Material" :
                                (rarity == ItemRarity::RARE) ? "Quality " + materialType + " Material" :
                                (rarity == ItemRarity::UNCOMMON) ? "Good " + materialType + " Material" :
                                materialType + " Material";
                material.description = "A crafting material. Can be used to craft items.";
                material.type = ItemType::QUEST;
                material.rarity = rarity;
                material.isStackable = true;
                material.isUsable = false;
                material.quantity = (rarity == ItemRarity::LEGENDARY) ? 1 :
                                   (rarity == ItemRarity::EPIC) ? randomInt(1, 2) :
                                   (rarity == ItemRarity::RARE) ? randomInt(2, 3) :
                                   randomInt(2, 4);
                material.value = (static_cast<int>(rarity) + 1) * 5;
                drops.push_back(material);
            }
        }
    
        return drops;
    }

int CombatSystem::calculateExperience(const std::vector<Enemy>& enemies) const {
    int total = 0;
    for (const Enemy& enemy : enemies) {
        total += enemy.experienceReward;
    }
    
    
    if (gameDifficulty == 3) {
        total = static_cast<int>(total * 1.5f);
    } else if (gameDifficulty == 1) {
        total = static_cast<int>(total * 0.75f);
    }
    
    return total;
}

int CombatSystem::calculateGold(const std::vector<Enemy>& enemies) const {
    int total = 0;
    for (const Enemy& enemy : enemies) {
        total += enemy.goldReward + randomInt(-2, 5);
    }
    
    
    if (gameDifficulty == 1) {
        total = static_cast<int>(total * EASY_GOLD_MULT);
    } else if (gameDifficulty == 3) {
        total = static_cast<int>(total * HARD_GOLD_MULT);
    }
    
    return (total < 0) ? 0 : total;
}





void CombatSystem::log(const std::string& message) {
    combatLog.push_back(message);
}

void CombatSystem::displayMessage(const std::string& message, int delayMs) const {
    std::cout << "\n" << message << "\n";
    delay(delayMs);
}





bool quickCombat(Player& player, Enemy& enemy) {
    CombatSystem combat(player, 2);
    CombatResult result = combat.startCombat(enemy);
    return result.playerWon;
}

bool hasCombatItems(const Player& player) {
    for (const Item& item : player.inventory) {
        if (item.isUsable && item.type == ItemType::CONSUMABLE) {
            return true;
        }
    }
    return false;
}

std::vector<int> getCombatItemIndices(const Player& player) {
    std::vector<int> indices;
    for (size_t i = 0; i < player.inventory.size(); ++i) {
        const Item& item = player.inventory[i];
        if (item.isUsable && item.type == ItemType::CONSUMABLE) {
            indices.push_back(static_cast<int>(i));
        }
    }
    return indices;
}

int applyDifficultyModifier(int damage, int difficulty, bool isPlayerDamage) {
    if (difficulty == 1) {  
        if (isPlayerDamage) {
            return static_cast<int>(damage * 1.2f);
        } else {
            return static_cast<int>(damage * EASY_DAMAGE_MULT);
        }
    } else if (difficulty == 3) {  
        if (isPlayerDamage) {
            return static_cast<int>(damage * 0.9f);
        } else {
            return static_cast<int>(damage * HARD_DAMAGE_MULT);
        }
    }
    return damage;
}

std::string generateCombatMessage(const std::string& attackerName,
                                  const std::string& defenderName,
                                  int damage, bool isCrit, bool isMiss) {
    std::stringstream ss;
    
    if (isMiss) {
        ss << attackerName << " " << randomElement(COMBAT_MISS_TEXT) 
           << " " << defenderName << "!";
    } else if (isCrit) {
        ss << attackerName << " " << randomElement(COMBAT_CRIT_TEXT)
           << " " << defenderName << " for " << damage << " CRITICAL damage!";
    } else {
        ss << attackerName << " " << randomElement(COMBAT_HIT_TEXT)
           << " " << defenderName << " for " << damage << " damage.";
    }
    
    return ss.str();
}

}  
